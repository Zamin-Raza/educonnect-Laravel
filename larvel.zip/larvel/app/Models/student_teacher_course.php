<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class student_teacher_course extends Model
{
    public $timestamps = false;
    use HasFactory;
    protected $table = 'std_teacher_course';
}
