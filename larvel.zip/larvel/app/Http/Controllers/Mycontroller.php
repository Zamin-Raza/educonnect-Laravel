<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Models\users_detail;
use App\Models\courses;
use App\Models\teacher;
use App\Models\course_teacher;
use App\Models\student_teacher_course;

class Mycontroller extends Controller


    {

        public function showupdate(){
            return view("updateprofile");
        }

        public function pkgstore(Request $request)

            {
                $cid = $request->query('cid');
                $tid = $request->query('tid');
                $email = session('user_email');
                $checker = course_teacher::where('course_id', $cid)->where('teacher_id', $tid)->first();
    
                $add = new student_teacher_course;
                $add->course_id = $cid;
                $add-> teacher_id= $tid;
                $add->users_Email = $email;

                dump(session()->get('user_name'));

                $add->save();

                return redirect('/dashboard');

            
        }

        public function update($term) {
            $session_name = session('user_name');

            dump(session()->get('user_name'));
          
            $user = users_detail::where('name', $session_name)->first(); // Retrieve a single user
        
            if ($user) {
                session(['user_name' => $term]);
                $user->name = $term; // Set the new email value
                $user->save();
             
                // $user->Email = $term;
                
                dump(session()->get('user_name'));
                 // Change the email value here
                // $user->save(); // Save the updated email to the database
               // Update the email in the session
            }

           return redirect('/dashboard');
        
            // Retrieve and return the updated user
          
        }
        

     



        public function showsearch($term){
            $teacher = Teacher::where('name', 'LIKE', $term . '%')->get();

            // $teacher = teacher::where('name',term )->get();
            return($teacher);
        }
        public function showsimple () { return
            view('search');
            }
            // public function showtemp() { return
            //     view('template');
            //     }
        public function showHome () { return
            view('HomePage');
            }
        public function showcourse(){
            if (session()->has('user_email')) {
               
                $courseType = session('institute');

                $courses = courses::where('course_type', $courseType)->get();
                if ($courses->isNotEmpty()) {
                    // Courses exist, load the 'courses' view and pass the courses data
                    return view('courses')->with('courses', $courses);
                } else {
                    // No courses found for the given course type
                    return view('dashboard');
                }
            }
            }

            



            public function showteacher(){
                if (session()->has('user_email')) {
                   
                    $teacherType = session('institute');
    
                    $teachers = teacher::where('teach_ints', $teacherType)->get();
                    if ($teachers->isNotEmpty()) {
                        
                        return view('teachers')->with('teachers', $teachers);
                    } else {
                       
                        return view('dashboard');
                    }
                }
                }
                public function showpackage(){
                if (session()->has('user_email')) {
                    $teacherType = session('institute');
                
                    $randomTeachers = teacher::where('teach_ints', $teacherType)->get();
                    $teacherData = [];
                
                    if ($randomTeachers->isNotEmpty()) {
                        foreach ($randomTeachers as $teachall) {
                            $call = course_teacher::where('teacher_id', $teachall->ID)->first();
                            if ($call) {
                                $cfee = courses::where('course_ID', $call->course_id)->first();
                
                                // Store the data for each teacher in an array
                                $teacherData[] = [
                                    'teacher' => $teachall,
                                    'course_teacher' => $call,
                                    'course' => $cfee,
                                ];
                            }
                        }
                    }
                
                    return view('package')->with('teachers', $teacherData);
                }
            }
                
          

        
      

    public function searcher($term){
        $same = session("institute");
        $sortcourse = courses::where('course_name', 'LIKE', $term . '%')->where('course_type', $same)->get();

        return($sortcourse);

    }

    public function searcher2($term){
        $same = session("institute");
        $sortteacher = teacher::where('name', 'LIKE', $term . '%')->where('teach_ints', $same)->get();

        return($sortteacher);

    }

   
    public function image_update(Request $request) {

       
        $session_name = session('user_email');
        // dump(session()->get('user_email'));
      
        $user = users_detail::where('Email', $session_name)->first(); // Retrieve a single user
    
        if ($user) {
            $pic = $request->file('picture'); 
       
        if ($request->hasFile('picture')) {
            $pic = $request->file('picture');
            $picName = $pic->getClientOriginalName();
            $picType = $pic->getClientOriginalExtension();
            $picSize = $pic->getSize();
            $pic->move('uploads', $picName);
            $user->pic = 'uploads/' . $picName;
            session(['image' => $picName]);
            $user->save();
            dump(session()->get('image'));
            
        }
           
        }

       return redirect('/dashboard');
 
    }


        public function regdone (Request $request) {
                $user = new users_detail;
        $user->name = $request->input('name');
        $user->inst = $request->input('institution');  
        $user->DOB = $request->input('date_of_birth'); 
        $user->email = $request->input('email'); 
        $user->password = $request->input('password');
        $pic = $request->file('picture'); 
       
        if ($request->hasFile('picture')) {
            $pic = $request->file('picture');
            $picName = $pic->getClientOriginalName();
            $picType = $pic->getClientOriginalExtension();
            $picSize = $pic->getSize();
            $pic->move('uploads', $picName);
            $user->pic = 'uploads/' . $picName;
        }

        $user->save();


                return view('HomePage');
            }
    
            public function showRegistrationForm()
            {
                return view('registration'); // Assuming 'registration.form' is your view name
            }

            public function showsignin()
            {
                return view('signin'); // Assuming 'registration.form' is your view name
            }
            public function showInfo()
            {
                return view('todayAboutPage'); // Assuming 'registration.form' is your view name
            }
        
            public function showabout()
            {
                return view('AboutUs'); // Assuming 'registration.form' is your view name
            }
    
            public function showNotice()
            {
                return view('forSchoolPage'); // Assuming 'registration.form' is your view name
            }
            
            public function showCareer()
            {
                return view('Career'); // Assuming 'registration.form' is your view name
            }
            
            function check(Request $request)
            {
                if ($request->isMethod('post')) {
                    $email = request('email');
                    $password = request('password');
                    //$fishData = DB::select('select * from details where id = ?',[$id]);        
                    $user = users_detail::where('email', $email)->where('password', $password)->first();

                    
                    if($user){
                        $request->session()->put('user_email', $email);
                         $request->session()->put('user_name', $user->Name);
                          $request->session()->put('institute', $user->Inst); 
                          $request->session()->put('image', $user->pic); 
                          
                        dump($request->session()->get('user_email')); 
                        dump($request->session()->get('user_name'));
                        return redirect('/dashboard');

                    }
                    
                        
                        // Redirect to the dashboard or any other authenticated pag
                    else {
                        return view('Homepage');
                    }
                } else return view('HomePage');
            
            }

            public function viewdashboard()
            {
                if (session()->has('user_email')) {
                    return        view('dashboard');
                } else {
        
                    return redirect('HomePage');
                }
            }

            public function logout(Request $request)
            {
                // $request->session()->forget('user_name');
                // $request->session()->forget('user_email');
                $request->session()->flush();
                return redirect('/HomePage');
            }

            function Addteacher(Request $request){
                $user = new teacher;
        $user->name = $request->input('teacher_name');
        $user->teach_ints = $request->input('teaching_institution');  
        $user->DOB = $request->input(''); 
        $user->email = $request->input('email'); 
        $user->password = $request->input('password');

            }

           

        }