<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<form action="/submit" method="POST">
        <!-- Basic Text Field -->
        <label for="textfield" >Enter your name:</label><br>
        <input type="text" id="textfield" name="name" onkeyup="Showdata()" ><br><br>
        <ul id="mylist">
        <div id="contains">

        </div>
        </ul>

        <!-- <input type="submit" value="submit" onclick= "sub()" -->

   
        
    
</body>
<script src="js\search.js"></script>
</html>