<form method="POST" action="{{ url('/reg') }}">
    @csrf

    <div>
        <label for="name">Name</label>
        <input id="name" type="text" name="name" value="{{ old('name') }}" required autofocus>
    </div>

    <div>
        <label for="email">Email</label>
        <input id="email" type="email" name="email" value="{{ old('email') }}" required>
    </div>

    <div>
        <label for="password">Password</label>
        <input id="password" type="password" name="password" required autocomplete="new-password">
    </div>

    <div>
        <label for="password_confirmation">Confirm Password</label>
        <input id="password_confirmation" type="password" name="password_confirmation" required>
    </div>

    <div>
        <label for="father_name">Father's Name</label>
        <input id="father_name" type="text" name="father_name" value="{{ old('father_name') }}" required>
    </div>

    <div>
        <label for="date_of_birth">Date of Birth</label>
        <input id="date_of_birth" type="date" name="date_of_birth" value="{{ old('date_of_birth') }}" required>
    </div>

    <div>
        <label for="institute">Institute</label>
        <input id="institute" type="text" name="institute" value="{{ old('institute') }}" required>
    </div>

    <button type="submit">Register</button>
</form>
