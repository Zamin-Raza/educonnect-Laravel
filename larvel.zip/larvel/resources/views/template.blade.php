<!-- courses.blade.php -->
<link href="../CSS/courses.css" rel="stylesheet">
@extends('dashboard') <!-- Assuming you have a master layout file -->

@section('content')
    <h1 class="course-head">Available Courses</h1>
    
    @if($css->isNotEmpty())
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Type</th>
                    <th>Description</th>
                    <th>Fee</th>
                </tr>
            </thead>
            <tbody>
                @foreach($css as $course)
                    <tr>
                        <td>{{ $course->course_ID }}</td>
                        <td>{{ $course->course_name }}</td>
                        <td>{{ $course->course_description }}</td>
                        <td>{{ $course->type }}</td>
                        <td>{{ $course->fee }}</td>
                    </tr>
                @endforeach
            </tbody>

            
        </table>
    @else
        <p>No courses found for the selected type.</p>
    @endif
@endsection
