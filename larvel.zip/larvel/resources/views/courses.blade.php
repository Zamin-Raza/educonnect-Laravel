<!-- courses.blade.php -->
<link href="../CSS/courses.css" rel="stylesheet">
@extends('dashboard') <!-- Assuming you have a master layout file -->


@section('exclude-navigation')
    {{-- Empty section --}}
@endsection
@section('content')

<script src="js\search.js"></script>
    <h1 class="course-head">Available Courses</h1>
    <a href="/dashboard" class="btn btn-danger btn-logout">Dashboard</a><br><br>

    <label for="textfield" >Search by name :</label><br>
        <input type="text" id="textfield" name="name" onkeyup="searcher()" ><br><br>

        <ul id="mylist">

        </ul>
    
    @if($courses->isNotEmpty())
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Description</th>
                    <th>Type</th>
                    <th>Fee</th>
                </tr>
            </thead>
            <tbody>
                @foreach($courses as $course)
                    <tr>
                        <td>{{ $course->course_ID }}</td>
                        <td>{{ $course->course_name }}</td>
                        <td>{{ $course->course_description}}</td>
                        <td>{{ $course->course_type }}</td>
                        <td>{{ $course->fee }}</td>
                    </tr>
                @endforeach
            </tbody>
        </table>
    @else
        <p>No courses found for the selected type.</p>
    @endif
@endsection
