<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>For School Page </title>
  <link rel="stylesheet" href="../CSS/navBarStyle.css">
  <link rel="stylesheet" href="../CSS/forSchoolStyle.css">
  <link rel="stylesheet" href="../CSS/utilities.css"> 
</head>
<body class="MainContainer">
 
  <header class="headerContainer">
    <nav class="navContainer">
      <div class="logoLeftContainer">
        <img src="../images/Group 376.png" alt="logoContainer">
      </div>
      <div class="CenterAnchorTagsContainer">

        

          <a href="./HomePage.html">Home</a>
          <a class="toolsAnchor" href="###">Notices<img src="../images/Aladinpot.png" alt="Aladin Pot"></a>

        


      </div>
      <div class="rightContainer">
        </div>

    </nav>

  </header>
  <main class="mainContainer">
    <div class="headerMainContainer">
      <div class="leftCon">
      </div>
      <div class="centerCon">
        <h1 class="primary-Heading">Welcome To Notice Boards Page!</h1> 
      </div>
      <div class="rightCon" ></div>

    </div>

    <!-- Notice board sections -->
  <section class="noticeSection">
    <h2>Academic Duration</h2>
    <div class="noticeContent">
      <!-- Add notices here -->
      <div class="notice">
        <h3>Opening</h3>
        <p>The acadmey will be open today!</p>
      </div>
      <div class="notice">
        <h3>Closure</h3>
        <p>The acadmey will be close from December 24th to January 2nd for winter break.</p>
      </div>
      <div class="notice">
        <h3>Want Extra Help During Closure!!!</h3>
        <p>Mr. Zamin will be available for extra help sessions on Mondays and Wednesdays from 3 PM to 5 PM.</p>
      </div>
    
    </div>
  </section>

  <!-- Sales information -->
  <section class="salesSection">
    <h2>Sales!!!</h2>
    <div class="salesContent">
      <!-- Add sales information here -->
      <div class="sale">
        <h3>Book Sale</h3>
        <p>Get 40% off on all textbooks this week! Limited stock available.
          Get your text books related to your course by consulting witn teacher.
        </p>
      </div>
      <div class="sale">
        <h3>Winter Sale</h3>
        <p>Get 20% off on all courses available from December 24th to January 2nd</p>
      </div>
    </div>
  </section>

  <!-- Teacher absence -->
  <section class="absenceSection">
    <h2>Teacher Absence</h2>
    <div class="absenceContent">
      <!-- Add teacher absence info here -->
      <div class="absence">
        <h3>Mr. Shahryar</h3>
        <p>Mr. Shahryar will be absent on December 15th due to a training seminar.</p>
      </div>
      <div class="absence">
        <h3>Ms. Aliza</h3>
        <p>Ms. Aliza will be absent on December 17th due to sick leave.</p>
      </div>
      
    </div>
  </section>
   




       </div>
  </main>



</body>
</html>