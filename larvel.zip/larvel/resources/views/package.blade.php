

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Available Packages</title>
    <link rel="stylesheet" href="../CSS/prac.css">
    <script src="js\REG.js"></script>
</head>
<body>

<div class="header">
        <h1>Available Packages</h1>
        <a href="/dashboard">Dashboard</a>
    </div>
<link href="../CSS/package.css" rel="stylesheet">
@php
    $count = 1; // Assuming $count is initialized before this loop
@endphp
@foreach ($teachers as $teacherData)
    <div class="teacher-package" id="teacher-package-{{ $count }}">
        <h2>Course: {{ $teacherData['course']->course_name }}</h2>
        <p id="cid-{{ $count }}"><span class="miniHead">Course ID:</span> {{ $teacherData['course']->course_ID }}</p>
        <h2>Teacher Name :{{ $teacherData['teacher']->name }}</h2>
        <p id="tid-{{ $count }}">Teacher ID: {{ $teacherData['teacher']->ID }} </p>
        <p><span class="miniHead">Original Fee:</span>{{ $teacherData['course']->fee }}</p>
        <p><span class="miniHead">Discounted Fee Fee:</span>: {{ $teacherData['course']->fee - 499 }}</p>
        <button type="button" onclick="addbuy({{ $count }})" 
        id="buy-button-{{ $count }}">BUY COURSE</button>
    </div>

    @php
    $count++;
@endphp
@endforeach

    <!-- Display other relevant information -->


</body>

</html>