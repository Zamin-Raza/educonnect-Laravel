<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="../CSS/login.css">
</head>
<body>

<div class="contentContainer">
  <h1 class="primary-heading">Student Login Form</h1>
    <h5 class="primary-paragraph">Enter Your Email And Password To Login!!</h5>
  </div>
<div class="registrationForm">
        <form method="POST" action="{{ url('/signin') }}">
            @csrf
            <div>
                <label for="email">Email</label>
                <input id="email" type="email" name="email" value="{{ old('email') }}" required autofocus class="inputField">
            </div>
            <div>
                <label for="password">Password</label>
                <input id="password" type="password" name="password" required autocomplete="current-password" class="inputField">
            </div>
            <button type="submit" class="primary-button">Login</button>
        </form>
    </div>
</body>
</html>