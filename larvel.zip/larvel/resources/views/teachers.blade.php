<!-- courses.blade.php -->

@extends('dashboard') <!-- Assuming you have a master layout file -->


@section('exclude-navigation')
    {{-- Empty section --}}
@endsection

<script src="js\search.js"></script>


@section('content')
<a href="/dashboard" class="btn btn-danger btn-logout">update profile</a><br><br>
    <h1>Dashboard</h1>


    <label for="textfield" >Search by name :</label><br>
        <input type="text" id="textfield" name="name" onkeyup="searcher2()" ><br><br>
        <ul id="mylist">
    </ul>
    
    @if($teachers->isNotEmpty())
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Emai;</th>
                    <th>Specialization</th>
                    <th>Link_din</th>
                   
                </tr>
            </thead>
            <tbody>
            @foreach($teachers as $teacher)
                    <tr>
                        <td>{{ $teacher->ID}}</td>
                        <td>{{ $teacher->name }}</td>
                        <td><a href="mailto:?subject=Subject&body=Body%20of%20the%20email">{{ $teacher->email }}</a></td>
                        <td>{{ $teacher->specialization }}</td>
                        <td>{{ $teacher->teacher_int }}</td>
                        <td><a href="{{ $teacher->teacher_linkdn }}">{{ $teacher->teacher_linkdn }}</a></td>
                      
                    </tr>
                @endforeach
            </tbody>
        </table>
    @else
        <p>No teachers found for the selected type.</p>
    @endif
    
@endsection
