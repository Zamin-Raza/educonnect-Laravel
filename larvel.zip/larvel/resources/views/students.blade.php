<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Student Profile</title>
  <link rel="stylesheet" href="../CSS/students.css">

</head>
<body>
  <div class="container">
    <header>
      <h1>Student Profile</h1>
    </header>
    <section class="personal-info">
      <div class="profile-pic">
        <!-- Display student profile picture -->
        <img src="../images/My.jpg" alt="Profile Picture">
      </div>
      <div class="info">
        <h2>Shahryar Amjad</h2>
        <p>Address: <span>123 Main Street, City, Country</span></p>
        <p>Phone Number: <span>+1234567890</span></p>
      </div>
    </section>

    <section class="result-card">
      <h2>Result Card</h2>
      <div class="results">
        <div class="subject-result">
          <h3>Subject 1</h3>
          <p>Grade: A</p>
        </div>
        <div class="subject-result">
          <h3>Subject 2</h3>
          <p>Grade: B+</p>
        </div>
        <!-- Add more subject results as needed -->
      </div>
    </section>

    <section class="courses">
      <!-- Display online courses bought by the student -->
      <h2>Online Courses Bought</h2>
      <ul class="course-list">
        <li>Course 1</li>
        <li>Course 2</li>
        <!-- Add more courses -->
      </ul>
    </section>

    <section class="available-teachers">
      <!-- Display available teachers -->
      <h2>Available Teachers</h2>
      <ul class="teacher-list">
        <li>Teacher 1 <button class="chat-btn" onclick="startChat('Teacher 1')">Chat</button></li>
        <br>
        <li>Teacher 2 <button class="chat-btn" onclick="startChat('Teacher 2')">Chat</button></li>
        <!-- Add more teachers -->
      </ul>
    </section>

    <section class="chat">
      <!-- Chat section -->
      <h2>Chat with Teacher</h2>
      <div class="chat-messages" id="chat-messages">
        <!-- Display chat messages here -->
      </div>
      <form id="chat-form">
        <input type="text" id="message-input" placeholder="Type your message...">
        <button type="submit">Send</button>
      </form>
    </section>
  </div>

  <script>
    function startChat(teacherName) {
      const chatMessages = document.getElementById('chat-messages');
      chatMessages.innerHTML = ''; // Clear previous chat messages

      // Simulate initial message from teacher
      displayMessage(teacherName, 'Hello, how can I help you?');
    }

    document.getElementById('chat-form').addEventListener('submit', function(event) {
      event.preventDefault();
      const messageInput = document.getElementById('message-input');
      const message = messageInput.value.trim();
      if (message !== '') {
        displayMessage('Student', message); // Display student's message
        messageInput.value = ''; // Clear input field after sending
        setTimeout(function() {
          // Simulate teacher's response after a short delay
          displayMessage('Teacher', 'I will get back to you shortly.');
        }, 1000);
      }
    });

    // Function to display messages in the chat window
    function displayMessage(sender, message) {
      const chatMessages = document.getElementById('chat-messages');
      const messageElement = document.createElement('div');
      messageElement.classList.add('message');
      messageElement.innerHTML = `<strong>${sender}:</strong> ${message}`;
      chatMessages.appendChild(messageElement);
    }
  </script>
</body>
</html>