@extends('dashboard')  <!-- Assuming you have a master layout file -->

@section('exclude-navigation')
    {{-- Empty section --}}
@endsection

@section('content')
    <div class="container">
    <a href="/dashboard" class="btn btn-danger btn-logout">Dashboard</a><br><br>
        <h2>Edit Profile</h2>
        <input type="text" id="textfield" name="name"  >
    <button type = "button" class="btn btn-danger btn-logout"  onclick="umar()">Change name </button>
    <form method="post" action="\posted" 
    enctype="multipart/form-data" class="registrationForm">
    @csrf
        <label for="picture" class="custom-file-upload">
    Change Picture
    <input type="file" id="picture" name="picture" accept="image/*" class="inputField">
    <button type="submit" class="primary-button">Submit</button>
</form>
    <!-- <button type = "button" class="btn btn-danger btn-logout"  onclick="">Submit </button> -->
</label>

</div>

        
@endsection
