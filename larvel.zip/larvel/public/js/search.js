// function Showdata(){
//     
//     var term = document.getElementById("textfield").value;
//     const SuggestionList = document.getElementById("myList");
//     SuggestionList.innerHTML = '';
//     const endpoint = "/searchTabDisplay/"+term;
//     console.log(endpoint);
//     fetch(endpoint)
//         .then(response =>{
//             if(!response.ok){
//                 throw new Error('HTTP error! Status:' ${response.status});
//             }
//             return response.json();
//         });


// }


function confirmation(){
    
}

function searcher() {
    var term = document.getElementById("textfield").value.trim();
    const SuggestionList = document.getElementById("mylist");

    if (term === '') {
        // If the text field is empty, display all courses
        SuggestionList.innerHTML = '';
        SuggestionList.style.display = 'none'; // Hide the list

        // Display the table with all courses
        var table = document.querySelector('table');
        table.style.display = 'table'; // Show the table
    } else {
        var endpoint = "/courses/" + encodeURIComponent(term); // Ensure proper URL encoding

        fetch(endpoint)
            .then(response => {
                if (!response.ok) {
                    throw new Error('HTTP error! Status: ${response.status}');
                }
                return response.json();
            })
            .then(data => {
                // Hide the table
                var table = document.querySelector('table');
                table.style.display = 'none';

                // Show the list and display filtered courses
                SuggestionList.style.display = 'block';
                SuggestionList.innerHTML = '';

                const attributes = ["course_ID", "fee", "course_type" ,];
                   if (data.length === 0) {
                const noRecords = document.createElement('p');
                noRecords.textContent = 'No records found.';
                SuggestionList.appendChild(noRecords);
            }
            else {
                data.forEach(sortcourse => {
                    const heading = document.createElement('h5');
                    heading.textContent = sortcourse.course_name;
                    SuggestionList.appendChild(heading);

                    attributes.forEach(attribute => {
                        const listitem = document.createElement('li');
                        listitem.textContent = attribute + ": " + sortcourse[attribute];
                        SuggestionList.appendChild(listitem);
                    });
                });
            }
        })
                

                
            
            .catch(error => {
                console.error('Error', error);
            });
    }
}





function searcher2() {

    
    var term = document.getElementById("textfield").value.trim();
 
    const SuggestionList = document.getElementById("mylist");

    if (term === '') {
        
        // If the text field is empty, display all courses
        SuggestionList.innerHTML = '';
        SuggestionList.style.display = 'none'; // Hide the list

        // Display the table with all courses
        var table = document.querySelector('table');
        table.style.display = 'table'; // Show the table
    } else {

        
        var endpoint = "/teachers/" + encodeURIComponent(term); // Ensure proper URL encoding
        fetch(endpoint)
            .then(response => {
                if (!response.ok) {
                    throw new Error('HTTP error! Status: ${response.status}');
                }
                
                return response.json();
            })
            .then(data => {
                // Hide the table
                var table = document.querySelector('table');
                table.style.display = 'none';

                // Show the list and display filtered courses
                SuggestionList.style.display = 'block';
                SuggestionList.innerHTML = '';

                const teach = ["ID", "email", "specialization"];
                   if (data.length === 0) {
                const noRecords = document.createElement('p');
                noRecords.textContent = 'No records found.';
                SuggestionList.appendChild(noRecords);
            }
            else {
                data.forEach(sortteacher => {
                    console.log(sortteacher.name);
                    const heading = document.createElement('h5');
                    heading.textContent = sortteacher.name;
                    SuggestionList.appendChild(heading);

                    teach.forEach(attribute => {
                        const listitem = document.createElement('li');
                        listitem.textContent = attribute + ": " + sortteacher[attribute];
                        SuggestionList.appendChild(listitem);
                    });
                });
            }
        })
                            
            .catch(error => {
                console.error('Error', error);
            });
    }
}






// function searcher(){    
//     var term = document.getElementById("textfield").value
//     // alert(term);
  
//     const SuggestionList = document.getElementById("mylist");

//     var endpoint = "/courses/"+encodeURIComponent(term); // Ensure proper URL encoding

//     // alert(endpoint);

//     console.log(endpoint);
//         fetch(endpoint)
//         .then(response =>{
//             if(!response.ok){
//                 throw new Error('HTTP error! Status: ${response.status}');
//             }
//             return response.json();
//         })
//         .then(data=>{
//             SuggestionList.innerHTML = '';
//             data.forEach(sortcourse =>{
//                 const listitem = document.createElement('li');
//                 listitem.textContent = sortcourse.course_name;
               
//                 SuggestionList.appendChild(listitem);
//             });

//         })
//         .catch(error =>{
//             console.error('Error', error);
//         });

    
//     // Redirect or perform an action with the constructed endpoint
//     // window.location.href = endpoint;

// }

//     if(term===' '){
//         document.getElementById("contains").remove();
//     }
//     // alert(endpoint);
//     // SuggestionList.innerHTML = '';
  
//     console.log(endpoint);
//         fetch(endpoint)
//         .then(response =>{
//             if(!response.ok){
//                 throw new Error('HTTP error! Status: ${response.status}');
//             }
//             return response.json();
//         })
//         .then(data=>{
//             SuggestionList.innerHTML = '';
//             data.forEach(teacher =>{
//                 const listitem = document.createElement('li');
//                 listitem.textContent = teacher.name;
               
//                 SuggestionList.appendChild(listitem);
//             });

//         })
//         .catch(error =>{
//             console.error('Error', error);
//         });


function Showdata(){


    
    var term = document.getElementById("textfield").value
    // alert(term);
    const endpoint = "/search/"+ term;
    const SuggestionList = document.getElementById("mylist");
    if(term===' '){
        document.getElementById("contains").remove();
    }
    // alert(endpoint);
    // SuggestionList.innerHTML = '';
  
    console.log(endpoint);
        fetch(endpoint)
        .then(response =>{
            if(!response.ok){
                throw new Error('HTTP error! Status: ${response.status}');
            }
            return response.json();
        })
        .then(data=>{
            SuggestionList.innerHTML = '';
            data.forEach(teacher =>{
                const listitem = document.createElement('li');
                listitem.textContent = teacher.name;
               
                SuggestionList.appendChild(listitem);
            });

        })
        .catch(error =>{
            console.error('Error', error);
        });

}


