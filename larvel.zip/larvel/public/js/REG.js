function checker() {
    // Validate email using a regular expression
    const emailField = document.getElementById('email');
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(emailField.value)) {
      alert('Please enter a valid email address');
      return false;
    }
    const dobField = document.getElementById('date_of_birth');
    const dob = new Date(dobField.value);
    const today = new Date();
    if (dob >= today) {
      alert('Date of birth should be before today');
      return false;
    }
    const passwordField = document.getElementById('password');
  const password = passwordField.value;
  // const passwordRegex = /^(?=.*[0-9])(?=.*[!@#$%^&*])[a-zA-Z0-9!@#$%^&*]{8,}$/;
  // if (!passwordRegex.test(password)) {
  //   alert('Password must contain at least one digit and one special character');
  //   return false;
  // }
  //   return true;
  }

  function change() {
    var term = document.getElementById("textfield").value;
    const endpoint = "/dashboard/" + term;
    
    fetch(endpoint)
        .then(response => {
            if (!response.ok) {
                throw new Error(`HTTP error! Status: ${response.status}`);
            }
            return response.json();
        })
        .then(data => {
            const listitem = document.getElementById('myemail');
            listitem.textContent = data.email;
        })
        .catch(error => {
            console.error('Error', error);
        });
}

  function umar(){
    alert("chala");
  var term = document.getElementById("textfield").value;
  var endpoint = "/dashboard/" + encodeURIComponent(term); // Ensure proper URL encoding

  alert(endpoint);
  
  // Redirect or perform an action with the constructed endpoint
  window.location.href = endpoint;

}

function pic_change(){
  alert("chala");
var term = document.getElementById("picture").value;
var endpoint = "/dashboards/" + encodeURIComponent(term); // Ensure proper URL encoding

alert(endpoint);

// Redirect or perform an action with the constructed endpoint
window.location.href = endpoint;

}


function confirmLogout() {
  var confirmation = confirm("Are you sure you want to logout?");
  if (confirmation) {
      window.location.href = '/logout'; 
  } else {
      
  }
}



function addbuy(clickedId) {
  alert("chla");
  var confirmation = confirm("Are you sure you want to buy the course? "+document.getElementById('tid-' + clickedId).
  textContent.trim().split(": ")[1] );
 

  if (confirmation) {
    var cid = document.getElementById('cid-' + clickedId).textContent.trim().split(": ")[1];
    var tid = document.getElementById('tid-' + clickedId).textContent.trim().split(": ")[1];
  
    var data = { cid: cid, tid: tid };
  
    var queryString = Object.keys(data)
        .map(key => encodeURIComponent(key) + '=' + encodeURIComponent(data[key]))
        .join('&');
  
    // Redirect to the new route with the query parameter
    window.location.href = '/dashboards?' + queryString;
  } else {
      // Do nothing or provide feedback
  }

}


 



// function addbuy(click_id){
//   var cid = 'cid-'+click_id;
//   var tid = 'cid-'+click_id;
//   // var div = document.getElementById(divId);

//   var course_id = document.getElementById(cid);
//   var teacher_id = document.getElementById(tid);

//   var data = {cid:cid, tid: tid };

//     var queryString = Object.keys(data)
//         .map(key => encodeURIComponent(key) + '=' + encodeURIComponent(data[key]))
//         .join('&');

//     // Redirect to the new route with the query parameter
//     window.location.href = '/dashboards?' + queryString;
// }





  





  // function change() {

  //   var term = document.getElementById("textfield").value
  //   // alert(term);
  //   const endpoint = "/dashboard/"+term;
  
  //   // alert(endpoint);
  //   // SuggestionList.innerHTML = '';
  //   alert(endpoint);
  //   console.log(endpoint);
  //       fetch(endpoint)
  //       .then(response =>{
  //           if(!response.ok){
  //               throw new Error('HTTP error! Status: ${response.status}');
  //           }
  //           return response.json();
  //       })
  //       .then(data=>{
  //           data.forEach(user =>{
  //               const listitem = document.getElementById('myemail');
  //               alert(user.email);
  //               listitem.textContent = user.email;
        
  //           });

  //       })
  //       .catch(error =>{
  //           console.error('Error', error);
  //       });

  // }
