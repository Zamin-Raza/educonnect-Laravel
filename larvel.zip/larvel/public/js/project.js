window.onload = function() {
  if (window.location.pathname === "/HomePage") {

    
  // Check if the current URL matches a specific condition

      // Start a setInterval for a specific action
      var intervalId = setInterval(function() {
        var randomNum = getRandomInt(10, 60);
          // Perform actions at the specified interval
          alert("Buy Courses As soon AS Possible" + " " + randomNum + 
          "students have recently bought the courses");

          // For example, update content or perform other tasks
      }, 15000); // Execute every 5 seconds (5000 milliseconds)

      // Optionally, to stop the interval after a certain time
      setTimeout(function() {
          clearInterval(intervalId); // Clear the interval after 30 seconds
      }, 60000); 
    }
    // 30000 milliseconds = 30 seconds
  
};


function getRandomInt(min, max) {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}




const plusIcons = document.querySelectorAll(".plusIcon");
const crossIcons = document.querySelectorAll(".crossIcon");
const VideoIcon = document.querySelectorAll(".VideoIcon");
const singupForm=document.querySelector(".main-conatainer-Login-Form");
const resgistrationBUtton=document.querySelector("#registrationButton");
// const resgistrationBUtton = document.querySelectorAll(b);
const closeIconSignup=document.querySelector(".close-icon-Sign-up-Form");
const Login_form = document.querySelector(".main-conatainer");
const loginBtn=document.querySelector("#loginButton");
const closeIconLogin=document.querySelector(".closeIcon-login");
let imageArray;
const video = Array.from(document.getElementsByTagName("video"));
const hubergerIcon=document.querySelector('#menuIcon');
const mobileDrower=document.querySelector('.drowerMobile');
const closeIcon=document.querySelector('#closeIcon');

hubergerIcon.addEventListener('click',()=>{
  mobileDrower.classList.add('showDrowerMoile');
  mainBody.style.overflow='hidden';
});
closeIcon.addEventListener('click',()=>{
  mobileDrower.classList.remove('showDrowerMoile');
  mainBody.style.overflow='auto';
});

function saif(){
  alert("umar sath tehra hai");
}

resgistrationBUtton.addEventListener('click',()=>{
  singupForm.classList.add("show-Login_form");

});
loginBtn.addEventListener('click',()=>{
  Login_form.classList.add("show_main_container");
})

closeIconLogin.addEventListener('click',()=>{
  Login_form.classList.remove("show_main_container");
})


closeIconSignup.addEventListener('click', () => {
  console.log("Yes clicked");
  singupForm.classList.remove("show-Login_form");
});












plusIcons.forEach((plusIcon) => {
  plusIcon.addEventListener("click", (event) => {
    const element = event.target;
    const parentEle = event.target.parentNode;
    const parentNode = element.parentNode.parentNode;

    const crossIcon = parentEle.querySelector(".crossIcon");
    const answerDiv = parentNode.querySelector(".answerContentContainer");

    answerDiv.classList.add("showAnswerDiv");

    element.classList.add("hidePlusIcon");

    crossIcon.classList.add("showCrossIcon");
  });
});
crossIcons.forEach((crossIcon) => {
  crossIcon.addEventListener("click", (event) => {
    const element = event.target;
    const plusIcon = element.previousElementSibling;
    const answerDiv = element.parentNode.nextElementSibling;

    crossIcon.classList.remove("showCrossIcon");
    plusIcon.classList.remove("hidePlusIcon");
    answerDiv.classList.remove("showAnswerDiv");
  });
});

VideoIcon.forEach((videcard) => {
  videcard.addEventListener("click", (e) => {
    const parentDIv = e.target.parentNode;

    const images = parentDIv.getElementsByTagName("img");
    const video = parentDIv.getElementsByTagName("video");
    imageArray = Array.from(images);
    imageArray.forEach((ele) => {
      ele.classList.add("showVideoIcon");
      video[0].style.display = "block";
    });
  });
});

video.forEach((ele) => {
  ele.addEventListener("click", (e) => {
    e.stopPropagation();
    imageArray.forEach((image) => {
      image.classList.remove("showVideoIcon");
      ele.style.display = "none";
    });
  });
});



