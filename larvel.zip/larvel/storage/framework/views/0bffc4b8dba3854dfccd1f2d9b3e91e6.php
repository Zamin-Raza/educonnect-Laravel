<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
</head>
<body>
<p>User name: <?php echo e(session('user_name')); ?></p>
            <p>Email: <?php echo e(session('user_email')); ?></p>
    
</body>
</html>
<?php /**PATH C:\Users\PMLS\stdproject\resources\views/profile.blade.php ENDPATH**/ ?>