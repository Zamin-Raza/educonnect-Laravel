

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Available Packages</title>
    <link rel="stylesheet" href="../CSS/prac.css">
    <script src="js\REG.js"></script>
</head>
<body>

<div class="header">
        <h1>Available Packages</h1>
        <a href="/dashboard">Dashboard</a>
    </div>
<link href="../CSS/package.css" rel="stylesheet">
<?php
    $count = 1; // Assuming $count is initialized before this loop
?>
<?php $__currentLoopData = $teachers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $teacherData): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="teacher-package" id="teacher-package-<?php echo e($count); ?>">
        <h2>Course: <?php echo e($teacherData['course']->course_name); ?></h2>
        <p id="cid-<?php echo e($count); ?>"><span class="miniHead">Course ID:</span> <?php echo e($teacherData['course']->course_ID); ?></p>
        <h2>Teacher Name :<?php echo e($teacherData['teacher']->name); ?></h2>
        <p id="tid-<?php echo e($count); ?>">Teacher ID: <?php echo e($teacherData['teacher']->ID); ?> </p>
        <p><span class="miniHead">Original Fee:</span><?php echo e($teacherData['course']->fee); ?></p>
        <p><span class="miniHead">Discounted Fee Fee:</span>: <?php echo e($teacherData['course']->fee - 499); ?></p>
        <button type="button" onclick="addbuy(<?php echo e($count); ?>)" 
        id="buy-button-<?php echo e($count); ?>">BUY COURSE</button>
    </div>

    <?php
    $count++;
?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <!-- Display other relevant information -->


</body>

</html><?php /**PATH C:\Users\PMLS\stdproject\resources\views/package.blade.php ENDPATH**/ ?>