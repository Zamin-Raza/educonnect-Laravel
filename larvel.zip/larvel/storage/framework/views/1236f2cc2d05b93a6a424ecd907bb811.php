<!-- courses.blade.php -->
<link href="../CSS/courses.css" rel="stylesheet">
 <!-- Assuming you have a master layout file -->

<?php $__env->startSection('content'); ?>
    <h1 class="course-head">Available Courses</h1>
    
    <?php if($cs->isNotEmpty()): ?>
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Type</th>
                    <th>Description</th>
                    <th>Fee</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $cs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($course->course_ID); ?></td>
                        <td><?php echo e($course->course_name); ?></td>
                        <td><?php echo e($course->course_description); ?></td>
                        <td><?php echo e($course->type); ?></td>
                        <td><?php echo e($course->fee); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>

            
        </table>
    <?php else: ?>
        <p>No courses found for the selected type.</p>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\PMLS\stdproject\resources\views/template.blade.php ENDPATH**/ ?>