<form method="POST" action="<?php echo e(url('/login')); ?>">
    <?php echo csrf_field(); ?>

    <div>
        <label for="email">Email</label>
        <input id="email" type="email" name="email" value="<?php echo e(old('email')); ?>" required autofocus>
    </div>

    <div>
        <label for="password">Password</label>
        <input id="password" type="password" name="password" required autocomplete="current-password">
    </div>

    <div>
        <input type="checkbox" name="remember" id="remember">
        <label for="remember">Remember Me</label>
    </div>

    <button type="submit">Login</button>
</form>
<?php /**PATH C:\Users\PMLS\stdproject\resources\views/login.blade.php ENDPATH**/ ?>