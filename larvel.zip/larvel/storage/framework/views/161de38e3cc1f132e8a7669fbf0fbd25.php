  <!-- Assuming you have a master layout file -->

<?php $__env->startSection('exclude-navigation'); ?>
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
    <a href="/dashboard" class="btn btn-danger btn-logout">Dashboard</a><br><br>
        <h2>Edit Profile</h2>
        <input type="text" id="textfield" name="name"  >
    <button type = "button" class="btn btn-danger btn-logout"  onclick="umar()">Change name </button>
    <form method="post" action="\posted" 
    enctype="multipart/form-data" class="registrationForm">
    <?php echo csrf_field(); ?>
        <label for="picture" class="custom-file-upload">
    Change Picture
    <input type="file" id="picture" name="picture" accept="image/*" class="inputField">
    <button type="submit" class="primary-button">Submit</button>
</form>
    <!-- <button type = "button" class="btn btn-danger btn-logout"  onclick="">Submit </button> -->
</label>

</div>

        
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\PMLS\stdproject\resources\views/updateprofile.blade.php ENDPATH**/ ?>