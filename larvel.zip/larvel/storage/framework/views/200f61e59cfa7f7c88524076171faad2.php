<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Dashboard</title>
    <!-- Include Bootstrap CSS -->
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <!-- Include Dashboard CSS -->
    <link href="../CSS/dashboard.css" rel="stylesheet">
</head>
<body>

<header>
    <h1>Welcome to Online Academy!</h1>
    </div>
          
        </div>
  </header>

  <div class="container mt-5">
    <div class="row">
        <div class="col-md-12 user-profile">
            <div class="student-details-container">
                <p class="student-details"  >User name: <?php echo e(session('user_name')); ?></p>
                <p class="student-details" >Email: <?php echo e(session('user_email')); ?></p>
                <p class="student-details"><?php echo e(session('institute')); ?> Student</p>
                <!-- Other student details -->
                <p class="student-details">You have successfully logged in!</p>
                <img src="<?php echo e(session('image')); ?>" alt="Student Image">
                </div>

<?php if(!View::hasSection('exclude-navigation')): ?>
    <!-- Navigation buttons -->
    <a href="/courses" class="btn btn-danger btn-logout">Available Courses</a>
    <a href="/teachers" class="btn btn-danger btn-logout">Available Teachers</a>
    <a href="/template" class="btn btn-danger btn-logout">Available Packages</a><br><br>
    <a href="/updateprofile" class="btn btn-danger btn-logout">update profile</a><br><br>
    <!-- <a href="/template" class="btn btn-danger btn-logout">Courses r</a><br><br> -->
   
<?php endif; ?>
</div>
</div>
<main>
        <?php echo $__env->yieldContent('content'); ?> <!-- This is where child views will inject their content -->
    </main>

    <div>
    <a href="#" onclick="confirmLogout()" class="btn btn-danger btn-logout">Logout</a>
</div>

<!-- Include Bootstrap JS and Popper.js -->
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.1/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

</body>

<script src="js\REG.js"></script>
</html><?php /**PATH C:\Users\PMLS\stdproject\resources\views/dashboard.blade.php ENDPATH**/ ?>