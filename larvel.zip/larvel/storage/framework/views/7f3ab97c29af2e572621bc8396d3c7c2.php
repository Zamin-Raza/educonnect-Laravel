<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="../CSS/registration.css">
</head>
<body>
<div class="headerContainer">
  <div class="headerDesign">
    <!-- Your header content goes here -->
  </div>
  <div class="navContainer">
    <div class="RightContainer">
      <div class="anchorTagsContainer">
        <!-- Your navigation links go here -->
      </div>
    </div>
  </div>
</div>

  <div class="contentContainer">
  <h1 class="primary-heading">Student Registration Form</h1>
    <h4 class="primary-paragraph">Kindly Fill This Form For Your Registration!</h4>
  </div>



<form method="post" action="\registration" enctype="multipart/form-data" class="registrationForm" Onsubmit=" return checker()">
    <?php echo csrf_field(); ?>

    <label for="name" class="description">Name:</label>
    <input type="text" id="name" name="name" required class="inputField">

    <label for="address" class="description">Address:</label>
    <input type="text" id="address" name="address" required class="inputField">

    <label for="email" class="description">Email:</label>
    <input type="email" id="email" name="email" required class="inputField">

    <label for="password" class="description">Password:</label>
    <input type="password" id="password" name="password" required class="inputField">

    <label for="institution" class="description">Institution:</label>
    <select id="institution" name="institution" required class="inputField">
        <option value="school">School</option>
        <option value="college">College</option>
        <option value="university">University</option>
    </select>
    <label for="picture" class="description">Upload Picture:</label>
    <input type="file" id="picture" name="picture" accept="image/*" class="inputField">
    <div>
        <label for="date_of_birth">Date of Birth</label>
        <input id="date_of_birth" type="date" name="date_of_birth" value="<?php echo e(old('date_of_birth')); ?>" required>
    </div>

  <br>
    <button type="submit" class="primary-button">Register</button>
</form>
<script src="js\REG.js"></script>

</body>
</html><?php /**PATH C:\Users\PMLS\stdproject\resources\views/registration.blade.php ENDPATH**/ ?>