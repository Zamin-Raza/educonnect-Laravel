<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Your Online Academy</title>
  <link rel="stylesheet" href="../CSS/Aboutus.css">
</head>
<body>
  <header>
    <h1>Welcome to Online Academy!</h1>
    <nav>
      <ul>
        <li><a href="#about">About Us</a></li>
        <li><a href="#why-choose">Why Choose Us</a></li>
        <li><a href="#benefits">Benefits</a></li>
        <li><a href="#connect">Connect With Us</a></li>
      </ul>
    </nav>
  </header>

  <main>
    <section id="about">
      <h2>About Us</h2>
      <p>
        At Online Academy, we believe that learning should transcend boundaries, and our platform reflects this ethos. We offer a diverse range of courses catering to various subjects, levels, and interests. Our team comprises experienced educators dedicated to providing high-quality education in an engaging online environment.
        <br><br>
        <strong class="miniHeadings">Teachers:</strong> Our instructors are experts in their fields, passionate about imparting knowledge and fostering a love for learning. They employ interactive teaching methods and personalized approaches to cater to diverse learning styles, ensuring every student receives the attention they deserve.
        <br><br>
        <strong class="miniHeadings">Students:</strong> Our students are at the heart of everything we do. We provide them with comprehensive learning resources, interactive sessions, and a supportive community to help them thrive academically and personally.
        <br><br>
        <strong  class="miniHeadings">Parents:</strong> We understand the importance of parental involvement in a child's education. Therefore, we keep parents informed about their child's progress, course content, and upcoming events, fostering a collaborative relationship between home and school.
      </p>
    </section>

    <section id="why-choose">
      <h2>Why Choose Us</h2>
      <ul>
        <li><strong class="miniHeadings">Quality Education:</strong> Our academy is committed to providing top-notch education through experienced teachers and well-structured courses.</li>
        <li><strong class="miniHeadings">Flexible Learning:</strong> We offer flexibility in learning schedules, allowing students to pursue their education at their convenience.</li>
        <li><strong class="miniHeadings">Interactive Learning Environment:</strong> Our platform encourages interaction through live classes, discussions, and collaborative projects, fostering a dynamic learning atmosphere.</li>
        <li><strong class="miniHeadings">Parental Involvement:</strong> We keep parents informed and engaged in their child's educational journey, ensuring a supportive network for students.</li>
        <li><strong class="miniHeadings">Diverse Course Offerings:</strong> From core subjects to extracurricular activities, we provide a wide array of courses catering to varied interests and needs.</li>
      </ul>
    </section>

    <section id="benefits">
      <h2>Benefits</h2>
      <ul>
        <li>Personalized learning experiences tailored to individual student needs.</li>
        <li>Accessible education from anywhere with an internet connection, promoting inclusivity.</li>
        <li>Engaging and interactive sessions that encourage active participation.</li>
        <li>A supportive community fostering growth, collaboration, and creativity.</li>
        <li>Transparent communication with parents to ensure a holistic approach to education.</li>
      </ul>
    </section>

    <section id="connect">
      <h2>Connect With Us</h2>
      <p>
        Stay updated with the latest news, events, and educational insights by following us on:
        <br>
        <strong class="miniHeadings">Instagram:</strong> <a href="[Insert Instagram Link]">[Insert Instagram Handle]</a>
        <br>
        <strong class="miniHeadings">Facebook:</strong> <a href="[Insert Facebook Link]">[Insert Facebook Page Link]</a>
        <br>
        <strong class="miniHeadings">Contact Number:</strong> 0300-94837844
        <br>
        <strong class="miniHeadings">Address:</strong> 30007B College Road, Lahore, Pakistan
      </p>
    </section>
  </main>

  <footer>
    <p>&copy; 2023 [Your Online Academy Name]. All Rights Reserved.</p>
  </footer>
</body>
</html><?php /**PATH C:\Users\PMLS\stdproject\resources\views/AboutUs.blade.php ENDPATH**/ ?>