<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="styles.css">
  <title>Career Paths for Students</title>
  <link rel="stylesheet" href="../CSS/career.css">
</head>

<body>
  <header>
    <h1>Career Paths for Students</h1>
  </header>

  <section class="career-path">
    <div class="career-text">
      <h2>Software Development</h2>
      <div class="benefits">
        <h3>Benefits:</h3>
        <ul>
          <li>High Demand: The tech industry has a constant demand for skilled developers.</li>
          <li>Creativity: Coding allows you to bring your creative ideas to life.</li>
          <li>Flexibility: Work remotely and choose from a variety of projects.</li>
        </ul>
      </div>
      <div class="why-choose">
        <h3>Why Students Should Choose:</h3>
        <ul>
          <li>Marketable Skills: Learn skills highly sought after by employers.</li>
          <li>Innovation: Be at the forefront of technological advancements.</li>
          <li>Career Growth: Opportunities for advancement and entrepreneurship.</li>
        </ul>
      </div>
    </div>
    <div class="career-img">
      <img src="../images/img01.jpg" alt="Career Image">
    </div>
  </section>

  <section class="career-path">
    <div class="career-text">
    <h2>Digital Marketing</h2>
    <div class="benefits">
      <h3>Benefits:</h3>
      <ul>
        <li>Diverse Opportunities: From SEO to social media, explore various avenues.</li>
        <li>Data-Driven: Analyze and interpret data to drive marketing strategies.</li>
        <li>Remote Work: Many roles offer the flexibility of working from anywhere.</li>
      </ul>
    </div>
    <div class="why-choose">
      <h3>Why Students Should Choose:</h3>
      <ul>
        <li>In-Demand Skills: Digital marketing skills are essential in today’s business landscape.</li>
        <li>Creativity: Develop and implement creative campaigns.</li>
        <li>Analytics: Gain valuable analytical skills for data-driven decision-making.</li>
      </ul>
    </div>
</div>
    <div class="career-img">
        <img src="../images/img02.jpg" alt="Career Image">
      </div>
  </section>

  <section class="career-path">
    <div class="career-text">
    <h2>Healthcare Management</h2>
    <div class="benefits">
      <h3>Benefits:</h3>
      <ul>
        <li>Impactful Work: Contribute to the improvement of healthcare systems.</li>
        <li>Stable Industry: Healthcare management is a recession-resistant field.</li>
        <li>Leadership Opportunities: Progress into leadership roles within organizations.</li>
      </ul>
    </div>
    <div class="why-choose">
      <h3>Why Students Should Choose:</h3>
      <ul>
        <li>Combines Business and Healthcare: Ideal for those interested in both fields.</li>
        <li>Fulfilling Career: Make a positive impact on patient care and outcomes.</li>
        <li>Growing Industry: Healthcare management is expected to see continuous growth.</li>
      </ul>
    </div>
</div>
<div class="career-img">
    <img src="../images/img03.jpg" alt="Career Image">
  </div>
  </section>

  <section class="career-path">
    <div class="career-text">
    <h2>Graphic Design</h2>
    <div class="benefits">
      <h3>Benefits:</h3>
      <ul>
        <li>Creative Expression: Bring ideas to life through visual elements.</li>
        <li>Freelance Opportunities: Many designers work on a project basis.</li>
        <li>Portfolio Building: Constantly build and showcase a diverse portfolio.</li>
      </ul>
    </div>
    <div class="why-choose">
      <h3>Why Students Should Choose:</h3>
      <ul>
        <li>Visual Communication: Learn to communicate through images and design.</li>
        <li>Versatility: Skills applicable in various industries.</li>
        <li>Entrepreneurship: Start your design studio or freelance business.</li>
      </ul>
    </div>
    </div>
    <div class="career-img">
        <img src="../images/img04.jpg" alt="Career Image">
      </div>
  </section>

  <section class="career-path">
    <div class="career-text">
    <h2>Environmental Science</h2>
    <div class="benefits">
      <h3>Benefits:</h3>
      <ul>
        <li>Sustainability: Contribute to a more sustainable and eco-friendly future.</li>
        <li>Fieldwork: Opportunities for hands-on experience in nature.</li>
        <li>Global Impact: Addressing crucial environmental issues on a global scale.</li>
      </ul>
    </div>
    <div class="why-choose">
      <h3>Why Students Should Choose:</h3>
      <ul>
        <li>Passion for Nature: Ideal for those passionate about the environment.</li>
        <li>Interdisciplinary Learning: Integrates knowledge from various scientific fields.</li>
        <li>Research Opportunities: Contribute to scientific research on environmental issues.</li>
      </ul>
    </div>
    </div>
    <div class="career-img">
        <img src="../images/img05.jpg" alt="Career Image">
      </div>
  </section>

  <section class="career-path">
    <div class="career-text">
    <h2>Entrepreneurship</h2>
    <div class="benefits">
      <h3>Benefits:</h3>
      <ul>
        <li>Autonomy: Be your own boss and set your own schedule.</li>
        <li>Innovation: Bring innovative ideas and products to the market.</li>
        <li>Financial Potential: Successful ventures can be financially rewarding.</li>
      </ul>
    </div>
    <div class="why-choose">
      <h3>Why Students Should Choose:</h3>
      <ul>
        <li>Learning by Doing: Gain practical experience while building your own business.</li>
        <li>Problem Solving: Entrepreneurship involves solving real-world problems.</li>
        <li>Networking: Build a network of like-minded individuals and mentors.</li>
      </ul>
    </div>
</div>
<div class="career-img">
    <img src="../images/img06.jpg" alt="Career Image">
  </div>
  </section>

  <footer>
    <p>Encourage students to explore these career paths based on their interests, skills, and long-term goals. Each of these
      fields offers unique opportunities for growth and personal fulfillment.</p>
  </footer>
</body>

</html>
<?php /**PATH C:\Users\PMLS\stdproject\resources\views/Career.blade.php ENDPATH**/ ?>