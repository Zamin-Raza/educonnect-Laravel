<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title> Home Page </title>
  <link rel="stylesheet" href="../CSS/navBarHomeStyles.css">
  <link rel="stylesheet" href="../CSS/HomePage.css">
  <link rel="stylesheet" href="../CSS/utilities.css"> 
  <link rel="stylesheet" href="forget-password-Card.html">
  
</head>
<body class="MainContainer">
  <header class="headerContainer">
    <nav class="navContainer">
      <div class="logoLeftContainer">
        <img src="../images/Group 376.png" alt="logoContainer">
      </div>
      <div class="RightContainer">

        <div class="anchorTagsContainer">

          <a class="anchor" href="file:///Y:/5th%20Sem/Web%20Tevh/Final%20Project/Pages/HomePage.html " onclick="saif()">Home</a>
          <a class="anchor" href="/todayAboutPage">Info Page</a>
          <a class="anchor" href="/AboutUs">About Us</a>
          <a class="anchor" href="./students.html">Student</a>
          <a class="anchor" href="./teacher.html">Teacher</a>

        </div>
        <div class="buttonContainer buttonContainerNav">
            <!-- <button class="primary-button" id="loginButton">Log In</button> -->
            <a href="/signin" class="primary-button" style="display: inline-block; padding: 10px 20px; background-color: #4CAF50; color: white; text-align: center; text-decoration: none; display: inline-block; font-size: 16px; 
            margin: 4px 2px; cursor: pointer; border-radius: 8px;">Login</a>

            <a href="/registration" class="primary-button" style="display: inline-block; padding: 10px 20px; background-color: #4CAF50; color: white; text-align: center; text-decoration: none; display: inline-block; font-size: 16px; 
            margin: 4px 2px; cursor: pointer; border-radius: 8px;">Registration</a>
          
        </div>
        <div class="barIconContainer">
            <img id="menuIcon" src="../images/icon-menu.svg" alt="Humberger Icon">
          </div>
        
        

      </div>





    </nav>
    <div class="drowerMobile">
        <svg  id="closeIcon" width="14" height="15" xmlns="http://www.w3.org/2000/svg">
            <path d="m11.596.782 2.122 2.122L9.12 7.499l4.597 4.597-2.122 2.122L7 9.62l-4.595 4.597-2.122-2.122L4.878 7.5.282 2.904 2.404.782l4.595 4.596L11.596.782Z" fill="#ffffff" fill-rule="evenodd"/>
        </svg>
        <!-- Here's a simplified explanation:
        
        - `<svg>`: Defines a container for vector graphics.
          - `width="14"` and `height="15"`: Set the width and height of the SVG image.
          - `xmlns="http://www.w3.org/2000/svg"`: Indicates the namespace for SVG graphics.
        
        - `<path>`: Draws the actual shape within the SVG.
          - `d`: Specifies the path commands that create the shape.
          - `fill="#ffffff"`: Sets the fill color of the shape (white in this case).
          - `fill-rule="evenodd"`: Determines the rule for filling the shape (using an even-odd rule).
        
        The `path` commands (`M`, `L`, `Z`) describe a series of lines and curves 
        to draw the shape resembling an "X" or close icon. When displayed, it will show
        a small white "X" graphic, typically used for closing or dismissing items in a user interface. -->
        
        <!-- <ul class="drowerAnchorTagsContainer">
          <li><a href="../HTML FIles/index.html">Home</a></li>
          <li><a href="../HTML FIles/AllChallengesPage.html">Challenge</a></li>
          <li><a href="###">Notification</a></li>
          <li><a href="../HTML FIles/HideChallengesPage.html">Hide Challenges</a></li>
          <li><a href="../HTML FIles/settingPage.html">Setting</a></li>
        </ul> -->
        
          <div class="buttonContainer">
            <button class="primary-Button SiginButtonDrower" id="sigInButton">Sign in</button>
            <button class="primary-Button SignUpButtonDrower" id="signUpButton">Sign up</button>
          

          </div>
      </div>

    <!-- <div class="sideAdaptSticker">
        <img src="../images/image 48.png" alt="Flag Image">

        <span class="description">Adapted to reforms</span>
    </div> -->

    <div class="mainImageContantContainer">

        <div class="contentContainer">
            <h1 class="primary-heading">For every student, every classroom. Real results.</h1>

            <p class="primary-paragraph">We are a nonprofit with the mission to provide a free, world-class
            education for anyone, anywhere.</p>

        </div>


        <div class="imageContainer">
            <img src="../images/heroImage.png" alt="Main Image">
        </div>

    </div>

    <div class="headerDesign">
        <img src="../images/Group 391.png" alt="Main Bg">
    </div>

  </header>

  <section class="learnAnythingSection">
    <img class="crownImg" src="../images/Fill 7.png" alt="Crown Image">

    <h1 class="secondary-Heading">You can learn anything</h1>

    <p class="secondary-Paragraph">Build a deep, solid understanding in math, science, and more.</p>

    <img class="learnAnythingImage" src="" alt="Insert YOUT HOME PAGE PIC">

  </section>

  <section class="MathrixSection">
    <img src="../images/23.png" alt="Z design ">
    
    <h1 class="secondary-Heading">We may have crossed paths in the media</h1>

    <div class="testomnialDivision">

        <div class="testimonialCard">
            <img src="../images/image 26.png" alt="Testimonial Card">

            <span class="CardThumbnailSpan">We have official professors</span>


        </div>
        <div class="testimonialCard">
            <img src="../images/image 27.png" alt="Testimonial Card">

            <span class="CardThumbnailSpan">We have everything to understand course</span>


        </div>
        <div class="testimonialCard">
            <img src="../images/mathrix-fr-49 1.png" alt="Testimonial Card">

            <span class="CardThumbnailSpan">We prepare you to the exam</span>


        </div>



    </div>



  </section>

  <section class="witnessSection">
    <img class="crownImg" src="../images/Fill 7.png" alt="Crown Image">

    <h1 class="secondary-Heading">They witness!</h1>

    <p class="secondary-Paragraph">What YouTube users say about us</p>


    <div class="MainCardsContainer">
        <div class="CardDiv">
            <img class="shadowOfCard" src="../images/Vector 2.png" alt="Card 1 Bg">
            <div class="card">
                <img class="quoteMarks" src="../images/ic.png" alt="wuote Marks">
                <div class="thumbnail-Content-Container">
                    <span class="thumbnailDescription" >Shahryar Amjad</span>
    
                </div>
    
                <p class="secondary-Paragraph">«My kids and I LOVE Mathrix! The courses are amazing, the teachers are interesting and experienced. Too bad we found out about Mathrix just now.»</p>
    
    
    
    
            </div>

        </div>

        <div class="CardDiv">
            <img class="shadowOfCard2" src="../images/2nd Card bg.png" alt="2nd Crad bg">
            <div class="card card2">
                <div class="thumbnail-Content-Container">
                    <img class="quoteMarks" src="../images/ic.png" alt="wuote Marks">
                    <span class="thumbnailDescription" >Zamin raza</span>
    
                </div>
    
                <p class="secondary-Paragraph">I improved my knowledge of everything I thought of and got the best grades in school! Learning is really easy and fun!</p>
    
    
    

            </div>

            

        </div>
        
      <div class="CardDiv">
        <img class="shadowOfCard3" src="../images/3rd Card bg.png" alt="3rd Card Bg">
        <div class="card">
            <div class="thumbnail-Content-Container">
                <img class="quoteMarks" src="../images/ic.png" alt="wuote Marks">
                <span class="thumbnailDescription" >Muneeb Ahmad</span>

            </div>

            <p class="secondary-Paragraph">Great videos, very interesting and entertaining! I am delighted! I recommend this site to everyone.
                He helped me a lot!</p>




        </div>
      </div>
      
    </div>
  </section>




  <section class="tutorialSection">
    <img class="crownImg" src="../images/Fill 7.png" alt="Crown Image">

    <h1 class="secondary-Heading">What We Offer?</h1>

    <p class="secondary-Paragraph">We Offer Many Subjects!!!</p>

    <div class="cardsContainer">

        <div class="parent-card">
            <div class="cards">
                <img src="../images/Group.png" alt="Mathematics ">
                <p class="cardPara">Mathematics</p>
            </div>
        </div>
        <div class="parent-card">
            <div class="cards">
                <img src="../images/Group (1).png" alt="Physical ">
                <p class="cardPara">Physical</p>
            </div>
        </div>
        <div class="parent-card">
            <div class="cards">
                <img src="../images/Layer 2.png" alt="SVT ">
                <p class="cardPara">SVT</p>
            </div>
        </div>
        <div class="parent-card">
            <div class="cards">
                <img src="../images/Group (2).png" alt="History ">
                <p class="cardPara">History</p>
            </div>
        </div>
        <div class="parent-card">
            <div class="cards">
                <img src="../images/Group (3).png" alt="Chemistry ">
                <p class="cardPara">Chemistry</p>
            </div>
        </div>
        <div class="parent-card">
            <div class="cards">
                <img src="../images/Group (4).png" alt="Geographi ">
                <p class="cardPara">Geographi</p>
            </div>
        </div>
        <div class="parent-card">
            <div class="cards">
                <img src="../images/Group (1).png" alt="Technology ">
                <p class="cardPara">Technology</p>
            </div>
        </div>
        <div class="parent-card">
            <div class="cards">
                <img src="../images/Group.png" alt="Philosophy ">
                <p class="cardPara">Philosophy</p>
            </div>
        </div>
        <div class="parent-card">
            <div class="cards">
                <img src="../images/Group (2).png" alt="Geographi">
                <p class="cardPara">Geographi</p>
            </div>
        </div>

    </div>

  </section>

  <section class="planCardsSection">
    <img src="../images/23.png" alt="Z design ">
    
    <h1 class="secondary-Heading planCardHeading">Discount Offers!</h1>
    <h4 style="text-align: center;">There are different discount offers due to level of the study and energy the 
        teachers utilize to teach them according to the
        higher/lower educational level of students.
    </h4>

    <div class="planCardsContainer">
        <img id="upperDesign" src="../images/patterns.png" alt="Upper design">
        <div class="planCard">
            <div class="discountSticekr">
                <img src="../images/Star 2.png" alt="Discount Sticker" id="discountStickerImg">
                <span id="discountPercent">-28%</span>
            </div>
            <div class="headerPlanCard">
                <img class="crownImg" src="../images/Fill 7.png" alt="Crown Image">

                <h1 class="secondary-Heading">School Plan</h1>

            </div>
            <div class="contentPlanCard">
                <span class="highWeightSpan">Rs. 2399<span class="lowWeightSpan">/ month</span></span>
    
                <p class="planCardParagraph">
                   This is the monthly plan for the students of school.
                </p>
    
                <button class="plancardButton">
                    Get premium
                </button>

            </div>
            



        </div>
        <div class="planCard">
            <div class="discountSticekr">
                <img src="../images/Star 2.png" alt="Discount Sticker" id="discountStickerImg">
                <span id="discountPercent">-28%</span>
            </div>
            <div class="headerPlanCard">
                <img class="crownImg" src="../images/Fill 7.png" alt="Crown Image">

                <h1 class="secondary-Heading">College Plan</h1>

            </div>
            <div class="contentPlanCard">
                <span class="highWeightSpan">Rs. 3399<span class="lowWeightSpan">/ month</span></span>
    
                <p class="planCardParagraph">
                   This is the monthly plan for the students of College.
                </p>
    
                <button class="plancardButton">
                    Get premium
                </button>

            </div>
            

        </div>
        <div class="planCard">
            <div class="discountSticekr">
                <img src="../images/Star 2.png" alt="Discount Sticker" id="discountStickerImg">
                <span id="discountPercent">-28%</span>
            </div>
            <div class="headerPlanCard">
                <img class="crownImg" src="../images/Fill 7.png" alt="Crown Image">

                <h1 class="secondary-Heading">University Plan</h1>

            </div>
            <div class="contentPlanCard">
                <span class="highWeightSpan">Rs. 4399<span class="lowWeightSpan">/ month</span></span>
    
                <p class="planCardParagraph">
                   This is the monthly plan for the students of Universities.
                </p>
    
                <button class="plancardButton">
                    Get premium
                </button>

            </div>
            
        </div>
        

        <img id="lowerDesign" src="../images/patterns1.png" alt="Lower design">




    </div>



  </section>


  <section class="videoCardsSection">
    <img src="../images/23.png" alt="Z design ">

    <h1 class="secondary-Heading">We may have crossed paths in the media</h1>

    <div class="videosCards videoCardsContainer">

        <div class="videoCard">
           
            <img src="../images/Rectangle 125.png" alt="Video Thumbnail" >
            <img class="VideoIcon" src="../images/video.png" alt="Video Icon" >
            <video controls  autoplay muted class="videos">
                <source src="../Videos/video.mp4" >
            </video>
           

            <p class="videoDescription">We have official professors</p>

        </div>
        
        <div class="videoCard">
            <img src="../images/Rectangle 123.png" alt="Video Thumbnail">
            <img class="VideoIcon" src="../images/video.png" alt="Video Icon">
            <video controls  autoplay muted class="videos">
                <source src="../Videos/video.mp4" >
            </video>
            <p class="videoDescription">How to better revice?</p>
        </div>
        <div class="videoCard">
            <img src="../images/Rectangle 127.png" alt="Video Thumbnail">
            <img class="VideoIcon" src="../images/video.png" alt="Video Icon">
            <video controls  autoplay muted class="videos">
                <source src="../Videos/video.mp4" >
            </video>
            <p class="videoDescription">Are you studying and still can't do it?</p>
        </div>




    </div>



    </section>

  <section class="frequentlyAskedQuestionSection">
    
    <h1 class="secondary-Heading">Frequently Asked Questions</h1>

    <div class="questionsContainer">
        <div class="question">
            <div class="questionContentContainer">
                <p>What does the subscription include?</p>
    
                <img class="plusIcon" src="../images/ic_plus.png" alt="Plus Icon">
                <img class="crossIcon" src="../images/ic_cross.png" alt="cross Icon">

            </div>
            <div class="answerContentContainer">
                You can pay online with confidence, all transactions made on the Mathrix.fr site are 100% secure and ensured by our payment partner Stripe. We pay particular attention to the security of your data: your credit card information is encrypted using the SSL (Secure Socket Layer) protocol and no bank data is stored on our network.
            </div>
            <div class="divider"></div>

        </div>
        <div class="question">
            <div class="questionContentContainer">
                <p>Do the courses conform to the official programs?</p>
                <img class="plusIcon" src="../images/ic_plus.png" alt="Plus Icon">
                <img class="crossIcon" src="../images/ic_cross.png" alt="cross Icon">

            </div>
            <div class="answerContentContainer">
                You can pay online with confidence, all transactions made on the Mathrix.fr site are 100% secure and ensured by our payment partner Stripe. We pay particular attention to the security of your data: your credit card information is encrypted using the SSL (Secure Socket Layer) protocol and no bank data is stored on our network.
            </div>
            <div class="divider"></div>

        </div>

        <div class="question">
            <div class="questionContentContainer">
                <p>Is the payment secured ?</p>
    
                <img class="plusIcon" src="../images/ic_plus.png" alt="Plus Icon">
                <img class="crossIcon" src="../images/ic_cross.png" alt="cross Icon">

                

            </div>
            <div class="answerContentContainer">
                You can pay online with confidence, all transactions made on the Mathrix.fr site are 100% secure and ensured by our payment partner Stripe. We pay particular attention to the security of your data: your credit card information is encrypted using the SSL (Secure Socket Layer) protocol and no bank data is stored on our network.
            </div>
            
            <div class="divider"></div>

        </div>
        


    </div>

  </section>


  <footer class="mainFooterContainer">

    <div class="footerUpperSection">
      <img src="../images/Fill 7.png" alt="Crown Image">

      <h1 class="secondary-Heading">OR SUNAO KI HAL CHAL !</h1>

    </div>

    <div class="footerContainer">
      <img id="footerLogo" src="../images/Logo (2).png" alt="Logo ">

      </div>

      <div class="rightContainer">

        <div class="socialAnchorTags">
            <a href=""><img id="facebook" src="../images/facebook.png" alt="Facebook"></a>
            <a href=""><img  id="twitter" src="../images/twitter.png" alt="Twitter"></a>
            <a href=""><img src="../images/instagram.png" alt="Instagram"></a>
            <a href=""><img src="../images/youtube.png" alt="Youtube"></a>
        </div>

      </div>

    </div>




  </footer>
  <div class="main-conatainer">
    <div class="forget-Passwrod">

        <img id="close-icon" class="closeIcon-login" src="../images/ic_close1.png" alt="Close">

        <img src="../images/Logo (2).png" alt="Logo">
        <h2 class="primary-heading-forget">Forget your passwrod?</h2>

        <div class="emailInput">
            <label for="email">Email</label>
            <input type="text" placeholder="Enter your Email" value="" id="email" class="email"
             name ="email">


            <button id="resetButton">Reset</button>

        </div>

        

        <a class="returnLoginAnchor" href="###">Return to the login page</a>
        
    </div>


</div>
<div class="main-conatainer-Login-Form">


    <div class="sign-form">

        <img id="close-icon" class="close-icon-Sign-up-Form" src="../images/ic_close1.png" alt="Close">

        <img src="../images/Logo (2).png" alt="Logo">
        <h2 class="primary-heading-login">Sign Up</h2>
        <div>
            <span id="haveaccountSpan">Have an account?</span>
            <a id="loginAnchor" href="###">Login</a>
        </div>

        <div class="emailInput">

          <div class="emailField">
            <label class="label" for="email">Email</label>
            <input type="text" placeholder="Enter your Email" id="email" class="emailLogin">

          </div>

            
            
            <label class="label" for="passwrod">Password</label>
            <div id="password-field">
                <input type="password" placeholder="Enter your Password" value="" id="email" class="emailLogin">
                <img src="../images/eyeIcon.png" alt="show password" id="eye-icon">
            </div>

            
            <input type="submit" value="Registration" class="emailLogin">

        </div>

    </div>

</div>
<!-- <script src="<?php echo e(asset('javascript/index.js')); ?>"></script> -->


</body>
<script src="js\project.js"></script>

</html><?php /**PATH C:\Users\PMLS\stdproject\resources\views/Homepage.blade.php ENDPATH**/ ?>