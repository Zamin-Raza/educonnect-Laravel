<!-- courses.blade.php -->

 <!-- Assuming you have a master layout file -->


<?php $__env->startSection('exclude-navigation'); ?>
    
<?php $__env->stopSection(); ?>

<script src="js\search.js"></script>


<?php $__env->startSection('content'); ?>
<a href="/dashboard" class="btn btn-danger btn-logout">update profile</a><br><br>
    <h1>Dashboard</h1>


    <label for="textfield" >Search by name :</label><br>
        <input type="text" id="textfield" name="name" onkeyup="searcher2()" ><br><br>
        <ul id="mylist">
    </ul>
    
    <?php if($teachers->isNotEmpty()): ?>
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Emai;</th>
                    <th>Specialization</th>
                    <th>Link_din</th>
                   
                </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $teachers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $teacher): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($teacher->ID); ?></td>
                        <td><?php echo e($teacher->name); ?></td>
                        <td><a href="mailto:?subject=Subject&body=Body%20of%20the%20email"><?php echo e($teacher->email); ?></a></td>
                        <td><?php echo e($teacher->specialization); ?></td>
                        <td><?php echo e($teacher->teacher_int); ?></td>
                        <td><a href="<?php echo e($teacher->teacher_linkdn); ?>"><?php echo e($teacher->teacher_linkdn); ?></a></td>
                      
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    <?php else: ?>
        <p>No teachers found for the selected type.</p>
    <?php endif; ?>
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\PMLS\stdproject\resources\views/teachers.blade.php ENDPATH**/ ?>