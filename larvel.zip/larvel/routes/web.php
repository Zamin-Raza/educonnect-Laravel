<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});


use App\Http\Controllers\Mycontroller;

Route::get('/', function () {
    return view('welcome');
});

Route::get('/HomePage', 'App\Http\Controllers\Mycontroller@showHome');
Route::get('/registration', 'App\Http\Controllers\Mycontroller@showRegistrationForm');
Route::get('/signin', 'App\Http\Controllers\Mycontroller@showsignin');
Route::post('/signin', 'App\Http\Controllers\Mycontroller@check');
Route::post('/registration', 'App\Http\Controllers\Mycontroller@regdone');
Route::get('/todayAboutPage', 'App\Http\Controllers\Mycontroller@showInfo');
Route::get('/AboutUs', 'App\Http\Controllers\Mycontroller@showabout');
Route::get('/forSchoolPage', 'App\Http\Controllers\Mycontroller@showNotice');
Route::get('/Career', 'App\Http\Controllers\Mycontroller@showCareer');
Route::get('/dashboard', 'App\Http\Controllers\Mycontroller@viewdashboard');
Route::get('/dashboards', 'App\Http\Controllers\Mycontroller@pkgstore');
Route::get('/logout', 'App\Http\Controllers\Mycontroller@logout');
Route::get('/courses', 'App\Http\Controllers\MyController@showcourse');
Route::get('/courses/{term}', 'App\Http\Controllers\MyController@searcher');
Route::get('/teachers', 'App\Http\Controllers\MyController@showteacher');
Route::get('/teachers/{term}', 'App\Http\Controllers\MyController@searcher2');
Route::get('/template', 'App\Http\Controllers\MyController@showpackage');
Route::get('/search/{term}', 'App\Http\Controllers\MyController@showsearch');
Route::get('/dashboard/{term}', 'App\Http\Controllers\MyController@update');
Route::post('/posted', 'App\Http\Controllers\MyController@image_update');
Route::get('/search', 'App\Http\Controllers\MyController@showsimple');
Route::get('/updateprofile', 'App\Http\Controllers\MyController@showupdate');
// Apply the middleware to routes









